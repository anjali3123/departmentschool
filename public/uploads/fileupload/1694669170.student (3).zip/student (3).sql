-- phpMyAdmin SQL Dump
-- version 4.9.10
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 13, 2023 at 07:21 PM
-- Server version: 8.0.34
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `author` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `stock` int NOT NULL DEFAULT '0',
  `isDeleted` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `name`, `author`, `stock`, `isDeleted`, `created_at`, `updated_at`) VALUES
(2, 'ChristmasPig', 'JK Rowling', 3, 0, '2023-05-18 05:30:29', '2023-05-31 03:28:44'),
(3, 'Whereabouts', 'Jhumpa Lahiri', 4, 0, '2023-05-18 05:31:32', '2023-05-31 03:28:53'),
(4, 'Dr. S. RadhaKrishnan', 'Indian Philosophy', 11, 0, '2023-05-18 05:34:20', '2023-06-27 08:03:03'),
(5, 'K. R. Malkani', 'India First', 5, 0, '2023-05-18 05:34:57', '2023-05-18 05:35:09'),
(6, 'vindaloo.programmers', 'sdsfs', 0, 1, '2023-05-31 03:46:29', '2023-05-31 03:46:29'),
(7, 'wfwe', 'rget', 0, 1, '2023-05-31 03:53:41', '2023-05-31 03:53:41'),
(8, 'n fg', 'jhl,jklj', 0, 1, '2023-05-31 06:58:16', '2023-05-31 06:58:16');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` int UNSIGNED NOT NULL,
  `name` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `name`, `code`, `status`, `created_at`, `updated_at`) VALUES
(1, 'B.C.A', '101', 1, '2023-05-15 03:17:32', '2023-05-28 23:57:38'),
(2, 'M.C.A', '203', 1, '2023-05-15 04:04:37', '2023-05-31 23:58:58');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `id` int NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `filename` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`id`, `name`, `filename`, `created_at`, `updated_at`) VALUES
(1, 'Anjali', '1', NULL, NULL),
(2, 't', '1', '2023-09-13 05:28:19', '2023-09-13 05:28:19'),
(3, NULL, '6', '2023-09-13 06:28:39', '2023-09-13 06:28:39'),
(4, NULL, '6', '2023-09-13 06:29:58', '2023-09-13 06:29:58'),
(5, NULL, '6', '2023-09-13 06:31:04', '2023-09-13 06:31:04');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2023_05_15_053429_create_departments_table', 2),
(6, '2023_05_15_121527_create_students_table', 3),
(7, '2023_05_16_121651_create_books_table', 4);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int UNSIGNED NOT NULL,
  `fname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phoneno` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `departmentid` int NOT NULL DEFAULT '0',
  `roll_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `isDeleted` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `fname`, `lname`, `email`, `phoneno`, `departmentid`, `roll_no`, `gender`, `address`, `isDeleted`, `created_at`, `updated_at`) VALUES
(4, 'Dhruv', 'Annam', 'dhruv@vindaloosofttech.com', '526398745', 2, '1002', 'female', 'vindaloosofttrch', 1, '2023-05-16 02:46:57', '2023-05-16 02:46:57'),
(5, 'Harsh', 'Annam', 'harsh@gmail.com', '4512879635', 2, '1003', 'male', 'Bapunagar', 0, NULL, NULL),
(6, 'Komal', 'Annam', 'komal@mailinator.com', '7889654552', 2, '1005', 'female', 'Vastral', 0, NULL, NULL),
(9, 'Divya', 'Patil', 'divya@mailinator.com', '4567891236955', 2, '10005', 'female', 'vindaloosofttrch', 0, NULL, NULL),
(10, 'Anjali', 'Annam', 'anjali@mailinator.com', '52263987415', 1, '10012', 'female', 'Viratnagar', 0, NULL, NULL),
(15, 'Anjali', 'Annam', 'anjali@gmail.com', '52634178956', 2, '52002', 'female', 'viratnagar', 1, NULL, NULL),
(16, 'Anjali', 'Annam', 'anjali@gmail.com', '52634178956', 1, '52002', 'female', 'viratnagar', 1, NULL, NULL),
(17, 'Anjali', 'Annam', 'anjali@gmail.com', '52634178956', 1, '52002', 'female', 'viratnagar', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `takebooks`
--

CREATE TABLE `takebooks` (
  `studentid` int NOT NULL,
  `id` int NOT NULL,
  `bookid` int NOT NULL,
  `libraryid` int NOT NULL,
  `status` tinyint NOT NULL DEFAULT '0',
  `to_date` date DEFAULT NULL,
  `return_date` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL,
  `updated_at` timestamp NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `takebooks`
--

INSERT INTO `takebooks` (`studentid`, `id`, `bookid`, `libraryid`, `status`, `to_date`, `return_date`, `created_at`, `updated_at`) VALUES
(3, 1, 2, 1, 1, '2023-05-31', '2023-05-30 09:53:41', '2023-05-30 04:22:59', '2023-05-30 04:23:41'),
(3, 2, 2, 1, 1, '2023-05-30', '2023-05-30 09:57:33', '2023-05-30 04:26:05', '2023-05-30 04:27:33'),
(3, 3, 3, 1, 0, '2023-05-31', NULL, '2023-05-30 04:26:44', '2023-05-30 04:26:44'),
(4, 4, 3, 1, 0, '2023-05-31', NULL, '2023-05-30 04:27:14', '2023-05-30 04:27:14'),
(5, 5, 4, 4, 0, '2023-06-01', NULL, '2023-05-31 03:50:53', '2023-05-31 23:40:52'),
(5, 6, 3, 1, 1, '2023-06-02', '2023-06-01 10:47:36', '2023-05-31 03:54:09', '2023-06-01 05:17:36'),
(6, 7, 3, 1, 0, '2023-06-11', NULL, '2023-05-31 03:54:22', '2023-05-31 04:41:54'),
(6, 8, 3, 3, 1, '2023-06-02', '2023-05-31 10:19:09', '2023-05-31 04:35:11', '2023-05-31 04:49:09'),
(9, 9, 2, 4, 0, '2023-06-22', NULL, '2023-06-01 00:02:41', '2023-06-01 00:02:41'),
(5, 10, 2, 5, 0, '2023-06-01', NULL, '2023-06-01 04:45:09', '2023-06-01 05:17:40'),
(10, 11, 5, 1, 1, '2023-06-30', '2023-06-27 13:34:24', '2023-06-27 08:03:20', '2023-06-27 08:04:24');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phoneno` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `isDeleted` tinyint NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `departmentid` int NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `email`, `phoneno`, `isDeleted`, `status`, `email_verified_at`, `password`, `departmentid`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Anjali', 'anjali', 'anjali@gmail.com', '4567891236', 1, 1, NULL, '$2y$10$aIYlDRUI9pExVbwNmJ2RB.E298PQifrC6WwZvhRapzzHKp4w0kALi', 1, NULL, NULL, NULL),
(3, 'Dhruv', 'dhruv', 'dhruv@mailinator.com', '4567891236', 0, 1, NULL, '$2y$10$n6upbmX9ABovm1w0N71tNuCqKocn5/y3LC80NGLCX76l46LvyNCKm', 1, NULL, NULL, NULL),
(4, 'Anjali Annam', 'anjali31', 'anjali@mailinator.com', '4567891236955', 0, 1, NULL, '$2y$10$I5EwOTjEH33uTlbwLEhMNuXEsB9ofxai9k9g53KHwrB52lPxAZnKi', 1, NULL, NULL, NULL),
(5, 'anjali', 'anjali', 'anamika@mailinator.com', '4567891236', 0, 1, NULL, '$2y$10$7zUwx5YM5D4r.TmtS1SmLOC3GoVWOtW9YRz64wBW8s1PBJoQVZXh2', 1, NULL, NULL, NULL),
(6, 'Anjali Annam', 'johnwick', 'anjali@vindaloosofttech.com', '52263987415', 1, 1, NULL, '$2y$10$uGPsBqcNbQdu3tVlYeNfw.najLc7k7q51Th1SOWlmiq4MgtQDOhQy', 1, NULL, NULL, NULL),
(7, 'Anamika', 'anamika', 'anamika@mailinator.com', '9632587410', 1, 1, NULL, '$2y$10$Ho0TM9Zj.e4ROBgQ0D4kl.Wp388aW/5LB2sLxhnw4B5sYBYLdwIXC', 1, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `takebooks`
--
ALTER TABLE `takebooks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `takebooks`
--
ALTER TABLE `takebooks`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
